git ls-files --other --exclude-standard --ignored
